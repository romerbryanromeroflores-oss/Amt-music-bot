# AMT Music Bot

## Features
- Slash Commands
- Music Playback
- Skip / Pause / Resume
- Voice Channel Support

## Commands
- /play
- /skip
- /pause
- /resume
- /leave

## Setup

1. Install Node.js
2. Upload files to Railway or another host
3. Run:

npm install

4. Open:
- index.js
- deploy-commands.js

Replace:
- YOUR_BOT_TOKEN
- YOUR_CLIENT_ID

5. Register commands:

npm run deploy

6. Start the bot:

npm start
